
// console.log("The replier bot is starting");

var SerialPort = require("serialport");
var port = new SerialPort("/dev/cu.usbmodem1421"); 


console.log("my bot starts");

var Twit = require ('twit');

var config = require('./configue');

var T = new Twit(config);



// var stream = T.stream('user');

// setInterval(nowForATwit, 1000*80);


var count = Math.floor(Math.random()*100); 

// port.on('open', function(){
console.log('Serial Port Opened');

port.on('data', function(data){
	
	if (data[0]!=0) 
	{
		console.log(data[0]);
		var tweet = 
		{
			status: "Hello World" + count	
		};
	count++;
	
		T.post ('statuses/update', tweet, tweeted);

	function tweeted(err, data, response){
		// console.log(data);
			if(err){
			console.log("something went wrong");
			}else{
			console.log("it worked");
			}
		}
	}
	// stream.on('content', msgEvent);
});
// });





// function msgEvent(){

// 		// console.log(data[0]);
// 		var newtweet = 'hello, my friend!';
// 		tweetIn(newtweet);
// 	}// console.log(replyto + ' ' + from);


// }

// function tweetIn(txt){
// 	var tweet = {
// 		status: txt
// 	}

// 		T.post('statuses/update', tweet, tweeted);

// 		function tweeted(err, data, response){
// 			if(err){
// 				console.log("something went wrong");
// 			}else{
// 				console.log("it worked");
// 			}
// 		}
// 	}


//FOR POSTING in a particular time

