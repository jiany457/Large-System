module.exports = {
  consumer_key:       '92pJCh3Fv4ceL2yn8DGTSt3in',
  consumer_secret:      'bjn91j5TAgW0pr3hBP4QNpO8DuHf1W5tXNYNVsOE5U9cca6jpJ',
  access_token:         '993936902414897153-UQs0TvR1Ql23hiIT2nfE0SE8Z1soUjQ',
  access_token_secret:  'YaZlGcHl7bokLjkMZyWDHNOe2qp2FkejXWOTVyAGi6x1x',
}