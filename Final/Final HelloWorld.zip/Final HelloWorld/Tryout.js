 var Twit = require ('twit');

var config = require('./configue');

var T = new Twit(config);

var exec = require('child_process').exec;
var fs = require('fs');   

//FOR POSTING in a particular time

setInterval(nowForATwit, 1000*80);

nowForATwit();

function nowForATwit(){
	var cmd = 'processing-java --sketch=`pwd`/image --run'
	exec(cmd, myProcessing); //execute this code in processing

	//get the image file from processing
	function myProcessing(){
		var filename = 'output.png'
		var inbetween = {
			encoding: 'base64' 
		}
		
		var  content = fs.readFileSync(filename, inbetween);
		T.post('media/upload', {media_data: content}, uploaded);

		//posting the image
	function uploaded(err, data, response){
		 //where i tweet
		  var id = data.media_id_string;
		  var tweet = {
				status: 'my post from node.js',
				media_ids:[id] // I can send in array; 
			}	
			T.post('statuses/update', tweet, tweeted);

	} 

	function tweeted (err, data, response) {
		if(err){
			console.log("Something went wrong");
		}else{
			console.log("It's working");
		}
	}
}
}