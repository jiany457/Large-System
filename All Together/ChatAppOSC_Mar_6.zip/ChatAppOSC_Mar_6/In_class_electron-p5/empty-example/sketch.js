function setup() {
  createCanvas(500, 500);
}

function draw() {
  rect(20, 30, 40, 50);
}